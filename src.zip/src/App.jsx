import React from 'react';
import { useTranslation } from 'react-i18next';
import Switcher from './components/Switcher';
// import Navbar from './components/Navbar';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Blog from './pages/Blog/Blog';
import './pages/Blog/Blog.css'
// import About from './pages/About/About';

const App = () => {
  const { t, i18n } = useTranslation();

  const changeLanguage = (language) => {
    i18n.changeLanguage(language);
  };

  return (
    <div>
      <Blog/>
      <div className="w-full flex justify-center">
        <select onChange={(e) => changeLanguage(e.target.value)}>
          <option value="en">En</option>
          <option value="ru">Ru</option>
        </select>
      </div>
      <div className="dark:bg-black">
        <Switcher />
      </div>
    </div>
  );
};

export default App;