import React from 'react'

function Nothing() {
  return (
    <div>404 Not Found</div>
  )
}

export default Nothing