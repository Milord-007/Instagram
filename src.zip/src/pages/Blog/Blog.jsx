import React from 'react'
import { useTranslation } from 'react-i18next';
import Switcher from '../../components/Switcher';
import pic2 from '../../assets/pic2.png'
import pic3 from '../../assets/pic3.png'
import pic4 from '../../assets/pic4.png'
import pic5 from '../../assets/pic5.png'
import pic6 from '../../assets/pic6.png'
import num from '../../assets/num.png'
import table from '../../assets/table.png'
import News from '../../assets/News.png'

function Blog() {

    const { t, i18n } = useTranslation();

    const changeLanguage = (language) => {
      i18n.changeLanguage(language);
    };
  return (
    <section className='max-w-[1400px] mx-auto dark:bg-white dark:text-[black] bg-black'>
      <div className='w-[95%] mx-auto pic min-h-[100vh]'>
    
      </div>
      <div className='w-[90%] mx-auto sm:p-0 pt-[50px] pb-[50px]'>
         <p className='text-[16px]    text-justify    w-[60%] mx-auto text-[#929292]'>{t("navbar.text1")}</p>
         <p className='text-[16px]  pt-[50px]  text-justify    w-[60%] mx-auto text-[#929292]'>{t("navbar.text1")}</p>

           <div className='w-[80%] mx-auto pt-[50px]'>
            <img src={pic2} alt="" />
          </div>
           
            <p className='text-[#FFFFFF] text-[25px] w-[60%] pt-[50px] mx-auto'>{t("navbar.text2")}</p>

            <p className='text-[#929292] text-[16px] text-justify w-[60%] pt-[50px] mx-auto font-[400]'>{t("navbar.text3")}</p>
            <p className='text-[#929292] text-[16px] text-justify w-[60%] pt-[50px] mx-auto font-[400]'>{t("navbar.text3")}</p>

            <div className='mx-auto w-[60%] bg-black mt-[50px]'>
               <img src={pic3} alt="" />
            </div>

             <div className='w-[80%] mx-auto flex justify-evenly pt-[50px]'>
               <div className='w-[45%]'>
                <div>
                    <img src={pic6} alt="" />
                </div>
                <div className='pt-[25px]'>
                    <img src={pic5} alt="" />
                </div>
               </div>
               <div className='w-[45%]'>
                   <img src={pic4} alt="" />
               </div>
             </div>
             <div className='mt-[30px] bg-black  mx-auto'>
                <img src={num} alt="" />
             </div>
             <p className='text-[#FFFFFF] text-[25px] w-[60%] pt-[50px] mx-auto dark:text-black'>{t("navbar.text4")}</p>
             <p className='text-[#929292] text-[16px] w-[60%] pt-[30px] mx-auto'>{t("navbar.text5")}</p>

             <p className='text-[#FFFFFF] text-[25px] w-[60%] pt-[50px] mx-auto dark:text-black'>{t("navbar.text6")}</p>
             <p className='text-[#929292] text-[16px] w-[60%] pt-[30px] mx-auto'>{t("navbar.text7")}</p>


              <div className='w-full  bck pt-[50px] pb-[50px] mt-8'>
               <h1 className='text-[18px] text-[#272727] text-center'>Do you have any questions?</h1>
               <p className='text-[69px] text-center font-[700]'>Contact us</p>
               <div className='text-center'>
               <input type="text" name="" id="" className='p-1 border-2 mr-2' placeholder='Enter your mail ' />
               <button className='bg-[black] text-white p-1 w-[100px] '>Send</button>
               </div>
              </div>

               <div className='w-[80%] mx-auto mt-8 bg-black'>
                <img src={table} alt="" />
               </div>
               <div className='w-[80%] mx-auto mt-8 bg-black'>
                <img src={News} alt="" />
               </div>


      </div>
    </section>
  )
}

export default Blog